// DEMO DATA ONLY. Never run against a real restaurant database.
// Safe to run more than once: it only adds what is missing and never deletes anything.
// Orders and payments are added to this script in later phases.
import { PrismaClient } from "@prisma/client";

if (process.env.NODE_ENV === "production") {
  throw new Error("Refusing to load demo data with NODE_ENV=production.");
}

const db = new PrismaClient();

type Demo = {
  name: string; price: number; description?: string; stock?: number; low?: number;
  variants?: [string, number][]; addons?: [string, number][];
};

const CATALOG: Record<string, Demo[]> = {
  Rice: [
    { name: "Jollof Rice", price: 2500, description: "Party-style smoky jollof", variants: [["Small", 1500], ["Medium", 2500], ["Large", 3500]], addons: [["Chicken", 1500], ["Beef", 1000], ["Egg", 300], ["Extra sauce", 300], ["Plantain", 500]] },
    { name: "Fried Rice", price: 2500, variants: [["Small", 1500], ["Medium", 2500], ["Large", 3500]], addons: [["Chicken", 1500], ["Beef", 1000], ["Egg", 300]] },
    { name: "Coconut Rice", price: 2800, variants: [["Medium", 2800], ["Large", 3800]] },
  ],
  Chicken: [
    { name: "Grilled Chicken", price: 3500, addons: [["Extra pepper sauce", 300]] },
    { name: "Peppered Chicken", price: 3000 },
  ],
  Soups: [
    { name: "Egusi Soup", price: 2500, addons: [["Extra meat", 800], ["Fish", 1000]] },
    { name: "Pepper Soup", price: 2200, addons: [["Extra meat", 800]] },
  ],
  Swallow: [
    { name: "Pounded Yam", price: 1200 },
    { name: "Eba", price: 800 },
  ],
  Snacks: [
    { name: "Meat Pie", price: 700, stock: 30, low: 8 },
    { name: "Puff Puff (5 pcs)", price: 500 },
    { name: "Moi Moi", price: 800 },
  ],
  Drinks: [
    { name: "Chapman", price: 1500 },
    { name: "Bottled Water", price: 300, stock: 48, low: 12 },
    { name: "Soft Drink", price: 500, stock: 36, low: 6 },
  ],
};

const CUSTOMERS = [
  { name: "Adaeze Okafor", phone: "08000000001", address: "12 Example Street, Garki" },
  { name: "Ibrahim Musa", phone: "08000000002", address: "5 Sample Close, Wuse 2" },
  { name: "Chiamaka Eze", phone: "08000000003", address: null },
  { name: "Tunde Bakare", phone: "08000000004", address: "Plot 9, Demo Estate, Gwarinpa" },
  { name: "Fatima Sani", phone: "08000000005", address: null },
  { name: "Emeka Nwosu", phone: "08000000006", address: "22 Test Avenue, Maitama" },
];

async function main() {
  const owner = await db.user.findFirst({ where: { role: { name: "OWNER" } } });
  if (!owner) throw new Error("Run `npm run db:seed` first so an owner account exists.");

  let cat = 0;
  for (const [categoryName, products] of Object.entries(CATALOG)) {
    const category = await db.category.upsert({
      where: { name: categoryName }, update: {}, create: { name: categoryName, sortOrder: cat },
    });
    cat++;
    let sort = 0;
    for (const p of products) {
      const existing = await db.product.findFirst({ where: { name: p.name, categoryId: category.id } });
      if (existing) continue;
      const created = await db.product.create({
        data: {
          name: p.name, description: p.description, price: p.price, categoryId: category.id,
          trackStock: p.stock !== undefined, sortOrder: sort++,
          variants: { create: (p.variants ?? []).map(([name, price], i) => ({ name, price, sortOrder: i })) },
          addons: { create: (p.addons ?? []).map(([name, price], i) => ({ name, price, sortOrder: i })) },
        },
      });
      if (p.stock !== undefined) {
        const item = await db.inventoryItem.create({ data: { productId: created.id, quantity: p.stock, lowStockThreshold: p.low ?? 5 } });
        await db.inventoryMovement.create({
          data: { inventoryItemId: item.id, type: "RECEIVED", quantityChange: p.stock, quantityAfter: p.stock, reason: "Demo opening stock", createdById: owner.id },
        });
      }
    }
  }

  for (const c of CUSTOMERS) {
    await db.customer.upsert({ where: { phone: c.phone }, update: {}, create: c });
  }

  if ((await db.discount.count()) === 0) {
    await db.discount.createMany({
      data: [
        { name: "Staff meal", type: "PERCENT", value: 20 },
        { name: "Loyalty ₦500 off", type: "FIXED", value: 500 },
      ],
    });
  }
  console.log("Demo catalogue and customers loaded.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
