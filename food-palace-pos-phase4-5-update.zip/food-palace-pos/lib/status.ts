import type { OrderTypeKey } from "@/lib/pricing";

export type OrderStatusKey = "PENDING" | "ACCEPTED" | "PREPARING" | "READY" | "OUT_FOR_DELIVERY" | "COMPLETED" | "CANCELLED";
export type PaymentStatusKey = "UNPAID" | "PARTIALLY_PAID" | "PAID" | "REFUNDED" | "PARTIALLY_REFUNDED";

export const ORDER_STATUSES: OrderStatusKey[] = ["PENDING", "ACCEPTED", "PREPARING", "READY", "OUT_FOR_DELIVERY", "COMPLETED", "CANCELLED"];
export const PAYMENT_STATUSES: PaymentStatusKey[] = ["UNPAID", "PARTIALLY_PAID", "PAID", "REFUNDED", "PARTIALLY_REFUNDED"];

export const ORDER_STATUS_LABEL: Record<OrderStatusKey, string> = {
  PENDING: "Pending", ACCEPTED: "Accepted", PREPARING: "Preparing", READY: "Ready",
  OUT_FOR_DELIVERY: "Out for delivery", COMPLETED: "Completed", CANCELLED: "Cancelled",
};
export const PAYMENT_STATUS_LABEL: Record<PaymentStatusKey, string> = {
  UNPAID: "Unpaid", PARTIALLY_PAID: "Part paid", PAID: "Paid", REFUNDED: "Refunded", PARTIALLY_REFUNDED: "Part refunded",
};
export const TYPE_LABEL: Record<OrderTypeKey, string> = { PICKUP: "Pickup", DELIVERY: "Delivery", DINE_IN: "Dine-in" };

/** The happy path for each kind of order. Delivery has the extra "out for delivery" step. */
export function flowFor(type: OrderTypeKey): OrderStatusKey[] {
  return ["PENDING", "ACCEPTED", "PREPARING", "READY", ...(type === "DELIVERY" ? (["OUT_FOR_DELIVERY"] as const) : []), "COMPLETED"];
}

export const isFinal = (s: OrderStatusKey) => s === "COMPLETED" || s === "CANCELLED";

/** Any open order can jump to any other step of its own flow (forward to skip, back to fix a slip).
 *  Completed and cancelled orders are final. Cancelling has its own form because it needs a reason. */
export function allowedTargets(type: OrderTypeKey, status: OrderStatusKey): OrderStatusKey[] {
  if (isFinal(status)) return [];
  return flowFor(type).filter((s) => s !== status);
}

export function nextStatus(type: OrderTypeKey, status: OrderStatusKey): OrderStatusKey | null {
  const flow = flowFor(type);
  const i = flow.indexOf(status);
  return i >= 0 && i < flow.length - 1 ? flow[i + 1] : null;
}

export const NEXT_ACTION_LABEL: Partial<Record<OrderStatusKey, string>> = {
  ACCEPTED: "Accept", PREPARING: "Start preparing", READY: "Mark ready", OUT_FOR_DELIVERY: "Out for delivery", COMPLETED: "Complete",
};
