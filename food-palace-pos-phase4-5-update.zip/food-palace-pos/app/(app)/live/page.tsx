import Link from "next/link";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { formatMoney } from "@/lib/money";
import { formatInZone } from "@/lib/dates";
import { cents } from "@/lib/payments";
import { balanceDueC } from "@/lib/payment-status";
import { resolveRange } from "@/lib/date-range";
import type { OrderTypeKey } from "@/lib/pricing";
import {
  nextStatus, NEXT_ACTION_LABEL, ORDER_STATUS_LABEL, TYPE_LABEL, type OrderStatusKey, type PaymentStatusKey,
} from "@/lib/status";
import { changeOrderStatus } from "@/lib/actions/order-flow";
import { ActionForm } from "@/components/action-form";
import { AutoRefresh } from "@/components/auto-refresh";
import { Elapsed } from "@/components/elapsed";
import { OrderStatusBadge, PaymentStatusBadge } from "@/components/status-badge";

export const metadata = { title: "Live orders" };
export const dynamic = "force-dynamic";

const itemSelect = { select: { productName: true, variantName: true, quantity: true } } as const;

export default async function LivePage() {
  const user = await requirePermission("orders.view");
  const s = await getSettings();
  const canManage = user.permissions.includes("orders.manage");
  const startOfToday = resolveRange("today", undefined, undefined, s.timezone).from!;
  const open: OrderStatusKey[] = ["PENDING", "ACCEPTED", "PREPARING", "READY", "OUT_FOR_DELIVERY"];

  const [active, completed, cancelled] = await Promise.all([
    db.order.findMany({ where: { status: { in: open } }, orderBy: { createdAt: "asc" }, take: 150, include: { items: itemSelect } }),
    db.order.findMany({ where: { status: "COMPLETED", completedAt: { gte: startOfToday } }, orderBy: { completedAt: "desc" }, take: 30, include: { items: itemSelect } }),
    db.order.findMany({ where: { status: "CANCELLED", cancelledAt: { gte: startOfToday } }, orderBy: { cancelledAt: "desc" }, take: 30, include: { items: itemSelect } }),
  ]);

  type Card = (typeof active)[number];
  const columns: { status: OrderStatusKey; orders: Card[] }[] = [
    { status: "PENDING", orders: [] }, { status: "ACCEPTED", orders: [] }, { status: "PREPARING", orders: [] }, { status: "READY", orders: [] },
    ...(s.enableDelivery || active.some((o) => o.status === "OUT_FOR_DELIVERY") ? [{ status: "OUT_FOR_DELIVERY" as OrderStatusKey, orders: [] as Card[] }] : []),
    { status: "COMPLETED", orders: completed },
  ];
  for (const o of active) columns.find((c) => c.status === o.status)?.orders.push(o);
  const sym = s.currencySymbol;

  const OrderCard = ({ o, final }: { o: Card; final?: boolean }) => {
    const status = o.status as OrderStatusKey;
    const type = o.type as OrderTypeKey;
    const next = final ? null : nextStatus(type, status);
    const balanceC = balanceDueC(cents(o.total), cents(o.amountPaid));
    return (
      <div className="rounded-xl border border-paper-300 bg-white p-3 shadow-sm">
        <div className="flex items-start justify-between gap-2">
          <Link href={`/orders/${o.id}`} className="font-display text-lg font-semibold text-palm-700 hover:underline">{o.orderCode}</Link>
          <span className="rounded bg-paper-200 px-1.5 py-0.5 text-xs font-semibold">{TYPE_LABEL[type]}{o.tableNumber ? ` ${o.tableNumber}` : ""}</span>
        </div>
        <p className="truncate text-sm font-medium">{o.customerName}</p>
        <ul className="mt-1 space-y-0.5 text-xs text-ink-800">
          {o.items.slice(0, 4).map((it, i) => <li key={i}>{it.quantity}× {it.productName}{it.variantName ? ` (${it.variantName})` : ""}</li>)}
          {o.items.length > 4 && <li className="text-ink-600">+{o.items.length - 4} more</li>}
        </ul>
        <div className="mt-2 flex items-center justify-between gap-2">
          <span className="text-sm font-semibold">{formatMoney(o.total, sym)}</span>
          <PaymentStatusBadge status={o.paymentStatus as PaymentStatusKey} />
        </div>
        <p className="mt-1 text-xs text-ink-600">
          {formatInZone(o.createdAt, s.timezone, "h:mm a")}
          {!final && <> · <Elapsed since={o.createdAt.toISOString()} /> ago</>}
        </p>
        {canManage && next && (
          <ActionForm
            action={changeOrderStatus} submitLabel={NEXT_ACTION_LABEL[next] ?? ORDER_STATUS_LABEL[next]} buttonClassName="mt-2 w-full"
            confirmMessage={next === "COMPLETED" && balanceC > 0 ? `${o.orderCode} still has ${formatMoney(balanceC / 100, sym)} unpaid. Complete it anyway?` : undefined}
          >
            <input type="hidden" name="id" value={o.id} /><input type="hidden" name="from" value={status} /><input type="hidden" name="to" value={next} />
          </ActionForm>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <AutoRefresh seconds={15} />
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 className="font-display text-2xl font-semibold">Live orders</h2>
          <p className="flex items-center gap-2 text-sm text-ink-600">
            <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-leaf-500" /> Updates every 15 seconds. Completed shows today only.
          </p>
        </div>
        <Link href="/orders" className="btn btn-secondary">All orders</Link>
      </div>

      <div className="-mx-3 flex gap-3 overflow-x-auto px-3 pb-3 sm:mx-0 sm:px-0">
        {columns.map((c) => (
          <section key={c.status} className="w-[270px] shrink-0 rounded-xl bg-paper-100 p-2">
            <header className="mb-2 flex items-center justify-between px-1">
              <OrderStatusBadge status={c.status} />
              <span className="text-sm font-semibold text-ink-600">{c.orders.length}</span>
            </header>
            <div className="space-y-2">
              {c.orders.length === 0 && <p className="px-1 py-4 text-center text-xs text-ink-600">Nothing here</p>}
              {c.orders.map((o) => <OrderCard key={o.id} o={o} final={c.status === "COMPLETED"} />)}
            </div>
          </section>
        ))}
      </div>

      <details className="panel p-3">
        <summary className="cursor-pointer text-sm font-semibold">Cancelled today ({cancelled.length})</summary>
        <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {cancelled.length === 0 && <p className="text-sm text-ink-600">No cancelled orders today.</p>}
          {cancelled.map((o) => <OrderCard key={o.id} o={o} final />)}
        </div>
      </details>
    </div>
  );
}
