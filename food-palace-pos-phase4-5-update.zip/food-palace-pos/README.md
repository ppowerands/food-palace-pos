# Food Palace POS

Restaurant POS and sales management (Next.js 15, TypeScript, Tailwind, Prisma, PostgreSQL).
This is **Phase 1**: project setup, full database schema, authentication, roles/permissions and restaurant settings.

## Run it locally

Requires Node 20.6+ and a PostgreSQL database (local, Docker, or a hosted one such as Neon/Supabase).

```bash
npm install
cp .env.example .env          # then edit DATABASE_URL, DIRECT_URL and the SEED_ADMIN_* values
npx prisma migrate dev --name init
npm run db:guards             # installs the "never delete / never edit history" database triggers
npm run db:seed               # roles, permissions, settings, payment methods, first owner
npm run dev
```

Open http://localhost:3000 and sign in with the SEED_ADMIN email and password.
Quick local Postgres with Docker:
`docker run --name fp-db -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=foodpalace -p 5432:5432 -d postgres:16`

Check it compiles: `npm run typecheck && npm run lint`

## Deploy to Vercel (when you're ready)

1. Create a hosted Postgres database and get a pooled URL and a direct URL.
2. In Vercel, add env vars `DATABASE_URL` (pooled) and `DIRECT_URL` (direct).
3. From your computer, with those two values in `.env`, run `npm run db:setup` once
   (applies migrations, installs the guards, seeds the owner). Re-run `npm run db:deploy && npm run db:guards` after future schema changes.
4. Push to GitHub and import the repo in Vercel. The build command `npm run build` already runs `prisma generate`.

Sessions use an httpOnly cookie and a database session table, so any phone, tablet or laptop can sign in at the same time.

## How the integrity rules are enforced

- **Application level:** there is no delete-order code path. Cancel, refund and void are the only routes (built in phases 3 to 5).
- **Database level:** `prisma/sql/immutability.sql` adds triggers so even a bug or a manual query can't delete orders, payments,
  refunds, audit entries or inventory movements, can't edit audit/status history/order lines, and can't change an order's number,
  billed amounts or a payment's amount. Re-run `npm run db:guards` after migrations (it is safe to repeat).
- **Order numbers** come from `RestaurantSettings.nextOrderNumber`, which can only increase, and `Order.orderNumber` is unique.
- **Money** is `Decimal(12,2)`; order items and payments snapshot names and prices at the time of sale.
- Because of those triggers, demo data can't be wiped by deleting rows. To reset a dev database use `npx prisma migrate reset`.

## Roles

Owner/Admin (everything), Manager, Cashier. Permissions live in the database and the owner can adjust Manager and
Cashier under Settings > Roles & permissions. Permissions are checked on the server for every page and action.

## Phases 4 and 5 (added)

No schema change and no new packages. Apply the update files and restart `npm run dev`.

- **Payments:** take payment at the POS (pay now / pay later, part payments, cash change, reference numbers) or later from the order page.
  Failed attempts can be logged without touching the balance. A repeated submit never records a payment twice.
- **Refunds and voids:** a refund gives money back (up to what was paid). A void reverses a whole payment entered by mistake and re-opens the balance.
  Payments and billed amounts are never edited; refunds are added as new rows. Cancelling a paid order can refund its payments in one step.
- **Receipts:** `/orders/<id>/receipt` is a printable receipt (browser print). Settings control header, footer, address and phone lines and auto-print.
- **Order flow:** pending → accepted → preparing → ready → (out for delivery, delivery orders only) → completed. Open orders can jump to any step of their own flow;
  completed and cancelled are final. Every change is saved with who and when. Stock goes down once, when an order is completed.
- **Cancelling:** needs a reason and confirmation; saves who, when, why. The order stays on record forever.
- **Pages:** Orders (search, filters, date ranges, pagination), order details with timeline, Live board (refreshes every 15 s), Payments (filters and pagination).
  The bell in the top bar shows pending orders.
- **Balance due** = total − paid. Refunds do not re-open it; voids do.

## Phases 2 and 3 (added)

No schema change, so there is **no new migration**. Copy the new files over your project, run `npm install` (no new packages),
and restart `npm run dev`.

Optional demo data (categories, products with sizes and add-ons, customers, discounts): `npm run db:seed:demo`.
It only adds, never deletes, and refuses to run when `NODE_ENV=production`.

- **Categories:** create, edit, reorder, activate or deactivate.
- **Products:** create/edit with sizes, add-ons, stock tracking and an active flag. Sizes and add-ons are switched off, never removed.
- **Customers:** searchable by name, phone or order number; profile with stats and order history. Phone numbers are normalised (`+234 801…` = `0801…`) so repeat customers aren't duplicated.
- **POS:** category tabs, product grid, size/add-on picker, cart, customer lookup, pickup/delivery/dine-in rules, discount, full bill preview, review step, confirm.
- **Order creation (server):** prices, fees, tax, discount and totals are recalculated from the database; the browser only sends ids and quantities.
  Order numbers come from a row-locked counter that only goes up; a duplicate request returns the same order instead of making a second one.
- **Billing formula:** total = subtotal − discount + service charge (dine-in only) + tax + delivery fee. Tax applies to (subtotal − discount + service charge), not delivery.

## What is in Phase 1

Schema for every model in the spec (plus a few supporting ones), login/logout, staff accounts (create, change role,
deactivate), change password and sign-out-other-devices, settings (restaurant, orders, payment methods, tax/service charge,
discounts, receipts, role permissions), and an audit log written for every one of those actions. The audit log screen itself arrives in phase 8.

## Not yet

Everything else in the sidebar is greyed out with its phase number. Logo and product images are links for now;
file uploads (e.g. Vercel Blob) come with products in phase 2. Login rate limiting and tighter security headers are on the phase 9 list.
